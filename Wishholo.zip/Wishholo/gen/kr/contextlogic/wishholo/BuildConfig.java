/** Automatically generated file. DO NOT MODIFY */
package kr.contextlogic.wishholo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}